# Run the app on localhost:8050
if __name__ == '__main__':
    print("============================= RERUN THE APP ====================================")
app.run_server(debug=True)